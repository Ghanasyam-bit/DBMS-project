Introduction :

  There are many people who thought of helping the orphans. But cannot proceed further due to lack of information about orphanage and their requirements.this tend to go to orphanages and do donations personally.But in Today's busy lives it is not that possible for everyone. This project will act as the best platform to the people who are kind towards the orphans.We are providing an online donation management for orphanages where one can directly donate to orphanages based on their need

  From our project we are providing users(donors) basic knowledge of the orphanages around them and the needs of those orphanages. And we are providing different donation portals like books,cloths,grocery,funds,toys..etc,.And the people who intrested to be volunteer of any orphanage they can register and the conformation details will be sent bt the orphanage.
  We are also providing orphanage login options to create their account to give their details,needs and update their needs that need to be displayed. and orphanages able to know the donations done to their orphanage and the details of volunteer who is intrested.


Tools used :

  ⦁	Frontend: HTML,CSS,JavaScript.  
  ⦁	Backend: PHP  
  ⦁	DataBase:MySQL


Features :

 ⦁ Login & signup (for orphanage)
 
 ⦁ Orphanage details collection
 
    ⦁ Enrollment
    ⦁ Requirements
    ⦁ Medical emergency 
    ⦁ Update details
    ⦁ Notifications 
    
 ⦁ Orphanage details display
 
    ⦁ Search bar 
    ⦁ Orphanage details 
    ⦁ Emergency details 
    
 ⦁ Online Donation interface


Conclusion :

  In our project we are bridging the gap between two sets of people - people who want to give , who want to try and make a difference along with those who are doing phenomenal work but don’t know how to reach out to the people who want to support them.
